"""Pure Python GOST cryptographic functions library.

PyGOST is free software: see the file COPYING for copying conditions.
"""

__version__ = "5.12"
